import React from "react"
import { useAxios } from "../../hooks"
import { photo } from "../types"

interface PhotosListProps {
  albumId: number
}

export const PhotosList: React.FC<PhotosListProps> = ({ albumId }) => {
  const { data: photos } = useAxios({
    url: `photos?albumId=${albumId}`,
  })

  return (
    <div>
      <ul>
        {photos?.map((photo: photo) => {
          return (
            <li key={photo?.id}>
              {
                <img
                  height={100}
                  width={200}
                  src={`${photo?.url}`}
                  alt={`${photo?.title}`}
                  title={photo?.title}
                />
              }
            </li>
          )
        })}
      </ul>
    </div>
  )
}
