import React, { useState } from "react"
import { useAxios } from "../../hooks"
import { album } from "../types"
import { PhotosList } from "./PhotosList"

interface AlbumListProps {
  userId: string
}
export const AlbumList: React.FC<AlbumListProps> = ({ userId }) => {
  const { data: albums } = useAxios({
    url: `albums?userId=${userId}`,
  })
  const [albumId, setAlbumId] = useState(null)

  return (
    <section>
      <h3>AlbumList</h3>
      <ul>
        {albums?.map((album: album) => {
          return (
            <div key={album?.id}>
              <li onClick={() => setAlbumId(album?.id)}>{album?.title}</li>
              {albumId === album?.id ? <PhotosList albumId={albumId} /> : null}
            </div>
          )
        })}
      </ul>
    </section>
  )
}
