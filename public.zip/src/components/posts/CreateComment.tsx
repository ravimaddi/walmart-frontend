import { FC, useState } from "react"

interface CreateComponentProps {
  handleCommentCreate: (...args: any) => void
  setIsCreateComment: (...args: any) => void
}
export const CreateComment: FC<CreateComponentProps> = ({
  handleCommentCreate,
  setIsCreateComment,
}) => {
  const [value, setValue] = useState("")

  return (
    <div>
      <form>
        <input
          type="text"
          onChange={(e) => setValue(e.target.value)}
          value={value}
        />
        <input
          type="submit"
          onClick={(e) => {
            handleCommentCreate(e, value)
          }}
        />
      </form>
      <button onClick={() => setIsCreateComment(null)}>Cancel</button>
    </div>
  )
}
