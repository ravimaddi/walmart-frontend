import { FC, useState } from "react"

interface EditPostProps {
  body: string
  handlePostUpdate: (...args: any) => void
  setEditPost: (...args: any) => void
}

export const EditPost: FC<EditPostProps> = ({
  body,
  handlePostUpdate,
  setEditPost,
}) => {
  const [value, setValue] = useState(body)

  return (
    <div>
      <form>
        <input
          type="text"
          onChange={(e) => setValue(e.target.value)}
          value={value}
        />
        <input
          type="submit"
          onClick={(e) => {
            handlePostUpdate(e, value)
          }}
        />
      </form>
      <button onClick={() => setEditPost(null)}>Cancel</button>
    </div>
  )
}
