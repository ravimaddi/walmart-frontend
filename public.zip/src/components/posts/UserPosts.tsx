import { FC, useEffect, useState } from "react"
import { useAxios } from "../../hooks"
import { Commnets } from "./Comments"
import { EditPost } from "./EditPost"

interface UserPostsProps {
  userId: string
}

export const UserPosts: FC<UserPostsProps> = ({ userId }) => {
  const { data } = useAxios({
    url: `posts?userId=${userId}`,
  })
  const [showCommnets, setShowCommnets] = useState(null)
  const [posts, setPosts] = useState([])
  const [editPost, setEditPost] = useState(null)
  const [searchValue, setSearchValue] = useState("")
  const [filteredPosts, setFilteredPosts] = useState(posts)
  const [isCreateComment, setIsCreateComment] = useState(null)
  useEffect(() => {
    if (data) {
      setPosts(data)
      setFilteredPosts(data)
    }
  }, [data])

  const handlePostUpdate = async (e: any, value: string) => {
    e.preventDefault()
    try {
      const response = await fetch(
        `https://jsonplaceholder.typicode.com/posts/${editPost}`,
        {
          method: "PATCH",
          body: JSON.stringify({
            body: value,
          }),
          headers: {
            "Content-type": "application/json; charset=UTF-8",
          },
        }
      )
      const updatedValue = await response.json()
      const newPosts = filteredPosts.map((post) => {
        if (post.id === editPost) {
          return { ...post, body: updatedValue?.body }
        }
        return post
      })
      setFilteredPosts(newPosts)
      setEditPost(null)
    } catch (error) {
      console.log(error)
    }
  }

  const handleDeletePost = async (postId: number) => {
    try {
      await fetch(`https://jsonplaceholder.typicode.com/posts/${postId}`, {
        method: "DELETE",
      })
      const newPosts = filteredPosts.filter((post) => post?.id !== postId)
      setFilteredPosts(newPosts)
    } catch (error) {
      console.log(error)
    }
  }

  const handleSearch = (e: any) => {
    setSearchValue(e.target.value)
    const newPosts = posts.filter((post) =>
      post?.title.includes(e.target.value)
    )
    setFilteredPosts(newPosts)
  }

  return (
    <section>
      <h3>Posts</h3>
      <input
        type="search"
        placeholder="Search post"
        onChange={(e) => {
          handleSearch(e)
        }}
        value={searchValue}
      />

      <ul>
        {filteredPosts?.map((userPost) => {
          return (
            <div key={userPost?.id}>
              <li>
                <p>
                  <b>Title: </b> {userPost?.title}
                </p>
                {editPost === userPost?.id ? (
                  <EditPost
                    body={userPost?.body}
                    handlePostUpdate={handlePostUpdate}
                    setEditPost={setEditPost}
                  />
                ) : (
                  <p>
                    <b>Body: </b>
                    {userPost?.body}
                  </p>
                )}
                <button onClick={() => setShowCommnets(userPost?.id)}>
                  Show Commnets
                </button>
                <button onClick={() => setEditPost(userPost?.id)}>
                  Update Post
                </button>
                <button onClick={() => handleDeletePost(userPost?.id)}>
                  Delete Post
                </button>
                <button
                  onClick={() => {
                    setShowCommnets(userPost?.id)
                    setIsCreateComment(userPost?.id)
                  }}
                >
                  Create Comment
                </button>
              </li>
              {showCommnets === userPost?.id ? (
                <Commnets
                  postId={showCommnets}
                  isCreateComment={isCreateComment}
                  setIsCreateComment={setIsCreateComment}
                />
              ) : null}
            </div>
          )
        })}
      </ul>
    </section>
  )
}
