import { FC } from "react"
import { Card, CardContent, Typography, Avatar } from "@mui/material"
import { User } from "./types"

interface UserProfileProps {
  user: User
}

export const UserProfile: FC<UserProfileProps> = ({ user }) => {
  return (
    <Card>
      <CardContent>
        <Avatar sx={{ width: 100, height: 100 }}>{user?.name[0]}</Avatar>
        <Typography variant="h5" component="div">
          User Details
        </Typography>
        <p> Name: {user?.name}</p>
        <p> Email: {user?.email}</p>
        <p>Phone: {user?.phone}</p>
        <p>Website: {user?.website}</p>
        <p>City: {user?.address?.city}</p>
      </CardContent>
    </Card>
  )
}
