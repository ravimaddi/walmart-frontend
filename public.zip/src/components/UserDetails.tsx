import { FC } from "react"
import { useParams } from "react-router-dom"
import { useAxios } from "../hooks"
import { UserProfile } from "./UserProfile"
import { UserPosts } from "./posts"
import { AlbumList } from "./albums"
import "../styles/userDetails.scss"

interface UserDetailsProps {
  [key: string]: any
}

export const UserDetails: FC<UserDetailsProps> = () => {
  const { id } = useParams()
  const { data: user } = useAxios({
    url: `users/${id}`,
  })

  return (
    <div className="userDetailsContainer">
      <UserProfile user={user} />
      <UserPosts userId={id} />
      <AlbumList userId={id} />
    </div>
  )
}
